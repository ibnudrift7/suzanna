<?php
$dt_DB = array();
 	//online
 	$dt_DB =  array(
 		'server' => 'localhost',
 		// 'username' => 'richmore_root',
 		// 'password' => '1q2w3e4r5t6y',
 		// 'database' => 'richmore_arsimetris',
 		'username' => 'root',
 		'password' => '',
 		'database' => 'dsgm',
	);